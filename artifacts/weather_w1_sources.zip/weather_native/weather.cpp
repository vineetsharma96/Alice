#include "world.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <iomanip>
#include <istream>
#include <ostream>
#include <stdexcept>

namespace uw {
namespace {
double blend(double a,double b,double t){return a+(b-a)*t;}
Conditions interpolate(const Conditions&a,const Conditions&b,double t){
    return {blend(a.offset,b.offset,t),blend(a.cloud,b.cloud,t),blend(a.rain,b.rain,t),blend(a.wind_x,b.wind_x,t),blend(a.wind_y,b.wind_y,t)};
}
void write(std::ostream&o,const Conditions&c){o<<c.offset<<' '<<c.cloud<<' '<<c.rain<<' '<<c.wind_x<<' '<<c.wind_y<<' ';}
void read(std::istream&i,Conditions&c){i>>c.offset>>c.cloud>>c.rain>>c.wind_x>>c.wind_y;}
bool valid(const Conditions&c){return std::isfinite(c.offset)&&std::abs(c.offset)<=4&&std::isfinite(c.cloud)&&c.cloud>=0&&c.cloud<=1&&std::isfinite(c.rain)&&c.rain>=0&&c.rain<=12&&std::isfinite(c.wind_x)&&std::abs(c.wind_x)<=10&&std::isfinite(c.wind_y)&&std::abs(c.wind_y)<=10;}
}
void ClimateConfig::check() const {
    if(!std::isfinite(year_s)||year_s<240||year_s>315576000||!std::isfinite(transition_s)||transition_s<1||transition_s>600||
       !std::isfinite(change_s)||change_s<transition_s||change_s>3600||!std::isfinite(temperature_bias_c)||std::abs(temperature_bias_c)>30)
        throw std::invalid_argument("INVALID_CLIMATE");
}
void World::configure_climate(const ClimateConfig& c){
    c.check();if(tick_!=0||climate_.enabled)throw std::invalid_argument("CLIMATE_REQUIRES_NEW_WORLD");
    climate_=c;weather_.rng=seed_^0x9e3779b97f4a7c15ULL;
    if(!weather_.rng)weather_.rng=1;
    weather_.next_s=c.change_s;
}
SeasonState World::season() const {
    const double years=static_cast<double>(tick_)*dt_/climate_.year_s;
    const double phase=(years-std::floor(years))*4;
    const unsigned index=std::min(3u,static_cast<unsigned>(phase));
    const double fraction=phase-index, t=fraction*fraction*(3-2*fraction);
    constexpr std::array<const char*,4> names{"spring","summer","autumn","winter"};
    constexpr std::array<double,4> temperature{12,24,11,0},daylight{.85,1,.75,.55},growth{1,.8,.35,.05},rain{.35,.15,.45,.4};
    auto value=[&](const auto& a){return blend(a[index],a[(index+1)%4],t);};
    return {names[index],static_cast<std::uint64_t>(std::floor(years)),fraction,value(temperature),value(daylight),value(growth),value(rain)};
}
double World::ambient_c() const {return season().temperature+climate_.temperature_bias_c+weather_.current.offset;}
std::string World::weather_kind() const {return weather_.current.rain>.05?"rain":weather_.current.cloud>.35?"cloudy":"clear";}
void World::update_weather(){
    if(!climate_.enabled)return;
    const double now=static_cast<double>(tick_)*dt_;
    if(now>=weather_.next_s){
        auto random=[&](){auto& n=weather_.rng;n^=n>>12;n^=n<<25;n^=n>>27;return static_cast<double>((n*2685821657736338717ULL)>>11)/9007199254740992.0;};
        weather_.from=weather_.current;
        const bool rainy=random()<season().rain_probability;
        const bool cloudy=rainy||random()<.45;
        weather_.target={8*random()-4,cloudy?.5+.5*random():.25*random(),rainy?2+10*random():0,8*random()-4,8*random()-4};
        weather_.start_s=now;weather_.end_s=now+climate_.transition_s;weather_.next_s=now+climate_.change_s;
        event("weather_transition","","",weather_kind());
    }
    const double t=weather_.end_s>weather_.start_s?std::clamp((now+dt_-weather_.start_s)/(weather_.end_s-weather_.start_s),0.0,1.0):1;
    weather_.current=interpolate(weather_.from,weather_.target,t*t*(3-2*t));
}
void World::write_weather(std::ostream& out) const {
    out<<" WEATHER1 "<<climate_.enabled<<' '<<climate_.year_s<<' '<<climate_.transition_s<<' '<<climate_.change_s<<' '<<climate_.temperature_bias_c<<' ';
    write(out,weather_.from);write(out,weather_.current);write(out,weather_.target);
    out<<weather_.start_s<<' '<<weather_.end_s<<' '<<weather_.next_s<<' '<<weather_.rng<<' ';
}
void World::read_weather(std::istream& in){
    std::string version;in>>version;
    if(version!="WEATHER1")throw std::invalid_argument("INVALID_WEATHER_VERSION");
    in>>climate_.enabled>>climate_.year_s>>climate_.transition_s>>climate_.change_s>>climate_.temperature_bias_c;
    read(in,weather_.from);read(in,weather_.current);read(in,weather_.target);
    in>>weather_.start_s>>weather_.end_s>>weather_.next_s>>weather_.rng;
}
void World::check_weather() const {
    climate_.check();
    if(!valid(weather_.from)||!valid(weather_.current)||!valid(weather_.target)||!weather_.rng||
       !std::isfinite(weather_.start_s)||weather_.start_s<0||!std::isfinite(weather_.end_s)||weather_.end_s<weather_.start_s||
       !std::isfinite(weather_.next_s)||weather_.next_s<0)
        throw std::invalid_argument("INVALID_WEATHER_STATE");
}
}
