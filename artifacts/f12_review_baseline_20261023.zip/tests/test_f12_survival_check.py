import tempfile
from pathlib import Path
import unittest

from scripts import f12_survival_check


class F12SurvivalCheckTests(unittest.TestCase):
    def test_connected_survival_smoke_preserves_native_control(self):
        with tempfile.TemporaryDirectory() as raw:
            result = f12_survival_check.run_check(
                output=Path(raw) / "survival.json",
                seconds=1.0,
                segment_seconds=1.0,
                population=2,
            )
        self.assertTrue(result["source_unchanged"])
        self.assertTrue(result["native_state_hash_matches_control"])
        self.assertTrue(result["integrated_replay_matches"])
        self.assertEqual(result["actors"], ["agent-1", "agent-2"])
        self.assertTrue(result["communication_handshake"]["feedback_changed"])
        self.assertEqual(result["integrated"]["final"]["f12"]["operation_count"], 4)


if __name__ == "__main__":
    unittest.main()
