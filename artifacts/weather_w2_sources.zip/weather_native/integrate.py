"""Build-only, fail-closed hooks; historical registered native files stay unchanged."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
DEST = Path(sys.argv[1])
DEST.mkdir(parents=True, exist_ok=True)
sources = {p.name: p.read_text(encoding='utf8') for p in (ROOT / 'core').glob('*') if p.suffix in ('.cpp', '.hpp')}


def patch(name, old, new):
    if sources[name].count(old) != 1:
        raise ValueError(f'weather integration anchor mismatch: {name}: {old[:70]}')
    sources[name] = sources[name].replace(old, new)


patch('world.hpp', '#include "thermal.hpp"', '#include "thermal.hpp"\n#include "weather.hpp"')
patch('world.hpp', '    void configure_ecology(', '''    void configure_climate(const ClimateConfig&);
    const ClimateConfig& climate() const { return climate_; }
    const WeatherState& weather() const { return weather_; }
    SeasonState season() const;
    double ambient_c() const;
    std::string weather_kind() const;
    const std::map<std::string,LocalExposure>& exposures() const { return exposures_; }
    void configure_ecology(''')
patch('world.hpp', '    Ecology ecology_;', '''    ClimateConfig climate_;
    WeatherState weather_;
    std::map<std::string,LocalExposure> exposures_;
    void update_exposure();
    void update_weather();
    void write_weather(std::ostream&) const;
    void read_weather(std::istream&);
    void check_weather() const;
    Ecology ecology_;''')
patch('world.cpp', '    return 100*std::max', '    return (climate_.enabled?season().daylight*(1-.65*weather_.current.cloud):1)*100*std::max')
patch('world.cpp', '        replenish();', '        update_weather();\n        replenish();')
patch('world.cpp', '        update_bodies();', '        update_bodies();\n        update_exposure();')
patch('bodies.cpp', 'tree_growth_kg_s_*dt_*kg', 'tree_growth_kg_s_*(climate_.enabled?season().growth:1)*dt_*kg')
patch('ecology.cpp', 'ecology_.forage_rate*dt_*kg', 'ecology_.forage_rate*(climate_.enabled?season().growth:1)*dt_*kg')
patch('world.cpp', '    write_ecology(out);', '    write_ecology(out);write_weather(out);')
patch('world.cpp', '    w.read_ecology(in);', '    w.read_ecology(in);w.read_weather(in);')
patch('world.cpp', 'void World::check_invariants() const {', 'void World::check_invariants() const {\n    check_weather();')
patch('world.cpp', '"UW9 "', '"UW10W "')
patch('world.cpp', 'magic!="UW9"', 'magic!="UW10W"')
patch('bindings.cpp', 'PYBIND11_MODULE(_underworld,m)', 'PYBIND11_MODULE(_underworld_weather,m)')
patch('bindings.cpp', 'm.attr("world_format")="UW9";', 'm.attr("world_format")="UW10W";')
patch('bindings.cpp', 'PYBIND11_MODULE(_underworld_weather,m)', '#include "weather_bindings.inc"\nPYBIND11_MODULE(_underworld_weather,m)')
patch('bindings.cpp', '        .def("step",', '''        .def("configure_climate",[](BoundWorld&w,py::dict p){configure_weather(w,p);})
        .def("weather_snapshot",[](const BoundWorld&w){return weather_snapshot(w);})
        .def("step",''')

for name, text in sources.items():
    (DEST / name).write_text(text, encoding='utf8', newline='\n')
manifest = {str(p.relative_to(ROOT)).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest()
            for folder in ('core', 'weather_native') for p in sorted((ROOT / folder).glob('*')) if p.is_file()}
(DEST / 'source_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf8')
